# Themes
Please make sure that the theme name and the file name are the same (+`.yaml`).

Example:

- theme: gruvbox
- filename: `gruvbox.yaml`
